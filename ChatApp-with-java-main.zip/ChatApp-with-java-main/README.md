# ChatApp-with-java

<h2>Tech-Stack<h2>
<ol>
  <li><b>Java Springboot</b></li>
  <li><b>MySQl</b></li>
  <li><b>HTML Thymeleaf</b></li>
</ol>
