package com.talk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalkApplicationTests {

	@Test
	void contextLoads() {
	}

}
